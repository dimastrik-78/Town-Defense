﻿using System;

namespace sringetowndefenceportotip
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ДОБРО ПОЖАЛОВАТЬ В ГОРОД КРИНЖА, КОТОРЫЙ ВЫ БЛАГОРОДНЫЙ АМОНГАСИК БУДЕТЕ ЗАЩИЩАТЬ\nЕСЛИ НЕ ЗАЩИТИТИ ТО ВЫ ЛОХ ОФИЦИАЛЬНА АНАНГВАГНМЗМНЖЖЖЖЖЖЖЛОТВБЭЗВЬТШЭ\nА теперь настроим игору :3");
            Console.Write("кол-во стартовой пшеницы: ");
            int pshenica = int.Parse(Console.ReadLine());
            Console.Write("сколько пшеницы добывает 1 крестьянин за цикл: ");
            int newpshenica = int.Parse(Console.ReadLine());
            Console.Write("сколько пшеницы жрет 1 воин за цикл: ");
            int pshenicanomnomnom = int.Parse(Console.ReadLine());
            int timenabeg = 15, nabegcnt=0, chenemy= 2, nchenemy=3, krest = 0, wariors=0;//timenaber в юнити должно иметь тип DeteTime чето там
            Console.WriteLine("Чтобы начать нажмите S\nЧтобы выйти нажмите E");
            string whatdo = Console.ReadLine();
            if (whatdo=="S")
            {
                while (whatdo!="E")
                {
                    Console.WriteLine("Аре ю будешь покупать людей?????\nНажмите Y если YES");
                    if (Console.ReadLine()=="Y")
                    {
                        Buyhumans(ref pshenica, ref krest, ref wariors);
                    }
                    PrintInfa(ref timenabeg, ref nabegcnt, ref chenemy, ref nchenemy, ref pshenica, ref krest, ref wariors);
                    SomeCalculations(ref timenabeg, ref pshenica, ref krest, ref wariors, ref pshenicanomnomnom, ref newpshenica);
                    FightCalculation(ref nabegcnt, ref chenemy, ref nchenemy, ref krest, ref wariors);
                    if (krest<=0&&wariors<=0)
                    {
                        Console.WriteLine("АХАХАХАХАХА ВЫ ЛОШАРА ЕБАНЫЙ АХАХАХАХКУЗЛОЩОЬШВКИЩ");
                        break;
                    }
                    Console.WriteLine($"Ура вы пережили набег номер {nabegcnt}, у вас {pshenica} пшеницы, {krest} крестьян, {wariors} воинов.");
                    Console.WriteLine("Если хотите выйти нажмите E");
                    whatdo = Console.ReadLine();
                }
            }
            return;
        }
        static void PrintInfa(ref int timenabeg, ref int nabegcnt, ref int chenemy, ref int nchenemy, ref int pshenica, ref int krest, ref int wariors)
        {
            nabegcnt++;
            if (nabegcnt%5==0)//5 это типа количество ходов через которые у тебя увеличется кол-во противников и времени, можешь сделать переменной в инспекторе
            {
                nchenemy += 2;
                chenemy += 2;
                timenabeg += 5;//также можешь сменить принцип изменения времени
            }
            if (nabegcnt%2==1)
            {
                Console.WriteLine($"Набег номер {nabegcnt} через {timenabeg} секунд, у вас {pshenica} пшеницы, {krest} крестьян, {wariors} воинов. На вас нападет {nchenemy} врагов");
            }
            else
            {
                Console.WriteLine($"Набег номер {nabegcnt} через {timenabeg} секунд, у вас {pshenica} пшеницы, {krest} крестьян, {wariors} воинов. На вас нападет {chenemy} врагов");
            }
        }
        static void Buyhumans(ref int pshenica, ref int krest, ref int wariors)//я щас осознала что лучше было сделать отдельно перегрузку для крестьян и для воинов вжвжвжвжвжвжвж
        {
            int howmatch = 0;
            Console.WriteLine("Вы хочите купить КрЕстЬяН????\nНажмите Y если YES");
            if (Console.ReadLine() == "Y")
            {
                Console.WriteLine("Сколько????");
                howmatch = int.Parse(Console.ReadLine());
                if (pshenica>=1*howmatch)//цены на крестьян и воинов тоже должны настраиваться в инспекторе у меня тут 1 за крестьянина и 3 за воина
                {
                    pshenica-=1*howmatch;
                    krest+=howmatch;
                }
                else
                {
                    Console.WriteLine("а вам пшеницы не хватило бы лол");
                }
            }
            Console.WriteLine("Вы хочите купить ВоиНоВ????\nНажмите Y если YES");
            if (Console.ReadLine() == "Y")
            {
                Console.WriteLine("Сколько????");
                howmatch = int.Parse(Console.ReadLine());
                if (pshenica >= 3 * howmatch)
                {
                    pshenica -= 3 * howmatch;
                    wariors += howmatch;
                }
                else
                {
                    Console.WriteLine("а вам пшеницы не хватило бы лол");
                }
            }
        }
        static void SomeCalculations(ref int timenabeg, ref int pshenica, ref int krest, ref int wariors, ref int pshenicanomnomnom, ref int newpshenica)//за условность взято то, что крестьянин добывает/воин жрет n пшениц в 1 секунду
        {
            pshenica += krest * newpshenica * timenabeg;
            if (pshenica==0)
            {
                while (wariors!=0)
                {
                    wariors--;
                }
            }
            pshenica -= wariors * pshenicanomnomnom * timenabeg;
        }
        static void FightCalculation(ref int nabegcnt, ref int chenemy, ref int nchenemy, ref int krest, ref int wariors)//тут тоже можно было разделить лол
        {
            if (nabegcnt % 2 == 1)
            {
                for (int i = nchenemy; i >0; i--)
                {
                    wariors--;
                    if (wariors<=0)
                    {
                        krest -= 3;
                        if (krest<=0)
                        {
                            return;
                        }
                    }
                }
            }
            else
            {
                for (int i = chenemy; i > 0; i--)
                {
                    wariors--;
                    if (wariors <= 0)
                    {
                        krest -= 3;
                        if (krest <= 0)
                        {
                            return;
                        }
                    }
                }
            }
        }
  
    }
}
